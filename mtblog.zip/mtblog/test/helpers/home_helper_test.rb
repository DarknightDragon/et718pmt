require 'test_helper'

class HomeHelperTest < ActionView::TestCase
end
